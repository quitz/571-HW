//
//  AboutMeViewController.swift
//  SlideMenueControllerExample
//
//  Created by quitz on 2016/11/27.
//  Copyright © 2016年 Jeff Schmitz. All rights reserved.
//

import UIKit
import SwiftSpinner
class CustomVC: UIViewController, UITableViewDataSource, UITableViewDelegate,UITextViewDelegate {


    @IBOutlet weak var detailTable: UITableView!
    @IBOutlet weak var detailImage: UIImageView!
    
    @IBOutlet weak var likeButton: UIButton!
    
    var llabel = ["First Name","Last Name","State","Gender","Birth date","Chamber","Fax","Twitter","Facebook","Website","Office","End Term"]
    let dict = ["01":"Jan","02":"Feb","03":"Mar","04":"Apr","05":"May","06":"Jun","07":"Jul","08":"Aug","09":"Sep","10":"Oct","11":"Nov","12":"Dec"]
    var text = ""
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = ""
    var ch = ""
    var fax = ""
    var twi = ""
    var fb = ""
    var web = ""
    var off = ""
    var et = ""
    var rlabel = [String]()
    
    
    @IBAction func likeLeg(_ sender: Any){
        let t = fn + ln
        if fav_leg_list.contains(t) {
            //likeButton.imageView?.image = UIImage(named: "Star")
            likeButton.setImage(UIImage(named: "Star"), for: [])
            
            let idx = fav_leg_list.index(of: t)!
            fav_leg_list.remove(at: idx)
            fav_leg.remove(at: idx)
        }
        else {
            likeButton.setImage(UIImage(named: "fillStar"), for: [])
            fav_leg.append(rlabel)
            fav_leg_list.append(t)
        }
        
        print(fav_leg)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        rlabel.append(fn)
        rlabel.append(ln)
        rlabel.append(state)
        rlabel.append(gen)
        let index = bd.index(bd.startIndex, offsetBy: 4)
        let t1 = bd.substring(to: index)
        let idx1 = bd.index(bd.startIndex, offsetBy: 5)
        let idx2 = bd.index(bd.startIndex, offsetBy: 7)
        let range = idx1..<idx2
        let t2 = bd.substring(with: range)
        let index1 = bd.index(bd.startIndex, offsetBy: 8)
        let t3 = bd.substring(from: index1)
        var tt = t3 + " " + dict[t2]! + " " + t1
        rlabel.append(tt)
        
        rlabel.append(ch)
        rlabel.append(fax)
        rlabel.append(twi)
        rlabel.append(fb)
        rlabel.append(web)
        rlabel.append(off)
        rlabel.append(et)
        rlabel.append(pic_url)
        //print(rlabel)
        //print(pic_url)
        let url = URL(string: pic_url)
        let data = try? Data(contentsOf: url!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
        detailImage.image = UIImage(data: data!)
        let t = fn + ln
        
        if fav_leg_list.contains(t) {
            likeButton.imageView?.image = UIImage(named: "fillStar")
        }
        else {
            likeButton.imageView?.image = UIImage(named: "Star")
        }
        
        
        // Do any additional setup after loading the view.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 12;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "detail", for: indexPath) as! CustomCell
        cell.leftLabel.text = llabel[indexPath.row]
        //cell.rightLabel.text = rlabel[indexPath.row]
        cell.right.text = rlabel[indexPath.row]
        cell.right.isEditable = false
        if indexPath.row == 7 && rlabel[indexPath.row] != "NA" {
            let linkAttributes = [
                NSLinkAttributeName: NSURL(string: rlabel[indexPath.row])!,
                NSForegroundColorAttributeName: UIColor.blue
                ] as [String : Any]
            
            let attributedString = NSMutableAttributedString(string: "Twitter Link")
            
            // Set the 'click here' substring to be the link
            attributedString.setAttributes(linkAttributes, range: NSMakeRange(0, 12))
            
            cell.right.delegate = self
            cell.right.attributedText = attributedString
            cell.right.isEditable = false;
        }
        else if indexPath.row == 8 && rlabel[indexPath.row] != "NA" {
            let linkAttributes = [
                NSLinkAttributeName: NSURL(string: rlabel[indexPath.row])!,
                NSForegroundColorAttributeName: UIColor.blue
                ] as [String : Any]
            
            let attributedString = NSMutableAttributedString(string: "Facebook Link")
            
            // Set the 'click here' substring to be the link
            attributedString.setAttributes(linkAttributes, range: NSMakeRange(0, 13))
            
            cell.right.delegate = self
            cell.right.attributedText = attributedString
            cell.right.isEditable = false;
        }
        else if indexPath.row == 9 && rlabel[indexPath.row] != "NA" {
            let linkAttributes = [
                NSLinkAttributeName: NSURL(string: rlabel[indexPath.row])!,
                NSForegroundColorAttributeName: UIColor.blue
                ] as [String : Any]
            
            let attributedString = NSMutableAttributedString(string: "Website")
            
            // Set the 'click here' substring to be the link
            attributedString.setAttributes(linkAttributes, range: NSMakeRange(0, 7))
            
            cell.right.delegate = self
            cell.right.attributedText = attributedString
            cell.right.isEditable = false;
        }
        else{
            
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        return true;
    }

}
