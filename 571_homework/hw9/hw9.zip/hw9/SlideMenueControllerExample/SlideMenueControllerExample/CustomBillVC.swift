//
//  CustomVC.swift
//  SlideMenueControllerExample
//
//  Created by quitz on 2016/11/27.
//  Copyright © 2016年 Jeff Schmitz. All rights reserved.
//

import UIKit
import SwiftSpinner

class CustomBillVC: UIViewController, UITableViewDataSource, UITableViewDelegate,UITextViewDelegate {
    
    @IBOutlet weak var billContent: UITextView!
    @IBOutlet weak var billTable: UITableView!
    
    @IBOutlet weak var likeButton: UIButton!
    
    var llabel = ["Bill ID","Bill Type","Sponsor","Last Action","PDF","Chamber","Last Vote","Status"]
    
    let dict = ["01":"Jan","02":"Feb","03":"Mar","04":"Apr","05":"May","06":"Jun","07":"Jul","08":"Aug","09":"Sep","10":"Oct","11":"Nov","12":"Dec"]
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = NSMutableAttributedString(string: " " )
    var ch = ""
    var fax = ""
    var twi = ""
    var ot = ""
    var rlabel = [String]()
    
    
    @IBAction func likeBill(_ sender: Any) {
        let t = fn + ln
        if fav_bill_list.contains(t) {
            //likeButton.imageView?.image = UIImage(named: "Star")
            likeButton.setImage(UIImage(named: "Star"), for: [])
            
            let idx = fav_bill_list.index(of: t)!
            fav_bill_list.remove(at: idx)
            fav_bill.remove(at: idx)
        }
        else {
            likeButton.setImage(UIImage(named: "fillStar"), for: [])
            fav_bill.append(rlabel)
            fav_bill_list.append(t)
        }
        
        print(fav_bill)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        rlabel.append(fn)
        rlabel.append(ln.uppercased())
        rlabel.append(state)
        var bd = gen
        let index = bd.index(bd.startIndex, offsetBy: 4)
        let t1 = bd.substring(to: index)
        let idx1 = bd.index(bd.startIndex, offsetBy: 5)
        let idx2 = bd.index(bd.startIndex, offsetBy: 7)
        let range = idx1..<idx2
        let t2 = bd.substring(with: range)
        let index1 = bd.index(bd.startIndex, offsetBy: 8)
        let index2 = bd.index(bd.startIndex, offsetBy: 10)
        let range1 = index1..<index2
        let t3 = bd.substring(with: range1)
        var tt = t3 + " " + dict[t2]! + " " + t1
        rlabel.append(tt)
        //rlabel.append(gen)
        rlabel.append("NA")
        rlabel.append(ch)
        
        var bd1 = fax
        let iindex = bd1.index(bd1.startIndex, offsetBy: 4)
        let it1 = bd1.substring(to: iindex)
        let iidx1 = bd1.index(bd1.startIndex, offsetBy: 5)
        let iidx2 = bd1.index(bd1.startIndex, offsetBy: 7)
        let irange = iidx1..<iidx2
        let it2 = bd1.substring(with: irange)
        let iindex1 = bd1.index(bd1.startIndex, offsetBy: 8)
        let iindex2 = bd1.index(bd1.startIndex, offsetBy: 10)
        let irange1 = iindex1..<iindex2
        let it3 = bd1.substring(with: irange1)
        var itt = it3 + " " + dict[it2]! + " " + it1
        rlabel.append(itt)
        //rlabel.append(fax)
        rlabel.append(twi)
        rlabel.append(ot)
        billContent.text = ot
        billContent.isEditable = false
        // Do any additional setup after loading the view.
        let t = fn + ln
        
        if fav_bill_list.contains(t) {
            likeButton.imageView?.image = UIImage(named: "fillStar")
        }
        else {
            likeButton.imageView?.image = UIImage(named: "Star")
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8;
        //return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "billdetail", for: indexPath) as! CustomBillDetailCell
        cell.leftLabel.text = llabel[indexPath.row]
        
        //cell.rightLabel.text = rlabel[indexPath.row]
        cell.right.text = rlabel[indexPath.row]
        cell.right.isEditable = false
        if indexPath.row == 4 && bd.string != "NA" {
            let linkAttributes = [
                NSLinkAttributeName: NSURL(string: bd.string)!,
                NSForegroundColorAttributeName: UIColor.blue
                ] as [String : Any]
            
            let attributedString = NSMutableAttributedString(string: "PDF Link")
            
            // Set the 'click here' substring to be the link
            attributedString.setAttributes(linkAttributes, range: NSMakeRange(0, 8))
            
            cell.right.delegate = self
            cell.right.attributedText = attributedString
            cell.right.isEditable = false;
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        return true;
    }
    
}
