//
//  AboutMeViewController.swift
//  SlideMenueControllerExample
//
//  Created by quitz on 2016/11/27.
//  Copyright © 2016年 Jeff Schmitz. All rights reserved.//

import UIKit
import SlideMenuControllerSwift
import Alamofire
import SwiftyJSON
import SwiftSpinner

var fav_leg = [[String]]()
var fav_leg_list = [String]()
var fav_bill = [[String]]()
var fav_bill_list = [String]()
var fav_com = [[String]]()
var fav_com_list = [String]()

class MainViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITabBarDelegate,UIPickerViewDelegate,UIPickerViewDataSource  {
    
    @IBOutlet weak var tblView: UITableView!
    
    @IBOutlet weak var tabBar: UITabBar!
    
    @IBOutlet weak var picker: UIPickerView!
    
    let data = ["title1","title2","title3","title4","title5"]
    let sub_data = ["stitle1","stitle2","stitle3","stitle4","stitle5"]
    var temp = ""
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = ""
    var ch = ""
    var fax = ""
    var twi = ""
    var fb = ""
    var web = ""
    var off = ""
    var et = ""
    var arrRes = [[String:AnyObject]]() //Array of dictionary
    var arrindex:[[[String:AnyObject]]] = []
    var arrindex_backup:[[[String:AnyObject]]] = []
    var indexList = ["A",  "C", "D", "F", "G", "H", "I",  "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "V", "W"]
    let indexList_backup = ["A",  "C", "D", "F", "G", "H", "I",  "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "V", "W"]
    
    let pkData = ["All States",
                  "Alaska",
                  "Alabama",
                  "Arkansas",
                  "American Samoa",
                  "Arizona",
                  "California",
                  "Colorado",
                  "Connecticut",
                  "District of Columbia",
                  "Delaware",
                  "Florida",
                  "Georgia",
                  "Guam",
                  "Hawaii",
                  "Iowa",
                  "Idaho",
                  "Illinois",
                  "Indiana",
                  "Kansas",
                  "Kentucky",
                  "Louisiana",
                  "Massachusetts",
                  "Maryland",
                  "Maine",
                  "Michigan",
                  "Minnesota",
                  "Missouri",
                  "Mississippi",
                  "Montana",
                  "North Carolina",
                  " North Dakota",
                  "Nebraska",
                  "New Hampshire",
                  "New Jersey",
                  "New Mexico",
                  "Nevada",
                  "New York",
                  "Ohio",
                  "Oklahoma",
                  "Oregon",
                  "Pennsylvania",
                  "Puerto Rico",
                  "Rhode Island",
                  "South Carolina",
                  "South Dakota",
                  "Tennessee",
                  "Texas",
                  "Utah",
                  "Virginia",
                  "Virgin Islands",
                  "Vermont",
                  "Washington",
                  "Wisconsin",
                  "West Virginia",
                  "Wyoming"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SwiftSpinner.show(duration: 2.0, title: "Fetching Data....")
        //SwiftSpinner.show()
        tabBar.delegate = self
        self.picker.dataSource = self
        self.picker.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
        var i = 1
        while i<=19 {
            arrindex.append([])
            i += 1
        }
        Alamofire.request("http://quitz-env.us-west-2.elasticbeanstalk.com/?dbName=legislators").responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["results"].arrayObject {
                    self.arrRes = resData as! [[String:AnyObject]]
                    self.arrRes.sort{($0["last_name"] as! String?)! < ($1["last_name"] as! String?)! }
                    
                    for i in 0 ..< self.arrRes.count {
                        let dict = self.arrRes[i]
                        var t = (dict["state_name"] as? String)!
                        var temp = String()
                        let index = t.index(t.startIndex, offsetBy: 0)
                        //print("line63")
                        temp.append(t[index])
                        let idx = self.indexList.index(of: temp)!
                        self.arrindex[idx].append(dict)
                        self.arrindex_backup = self.arrindex
                    }
                    
                    self.tblView.reloadData()
                }
            }
        }
        
        //print(arrRes.count)
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pkData.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pkData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if row == 0 {
            arrindex = arrindex_backup
            indexList = indexList_backup
        }
        else {
            let st = pkData[row]
            var t:[[[String:AnyObject]]] = []
            var m:[[[String:AnyObject]]] = []
            var i = 1
            while i<=19 {
                t.append([])
                m.append([])
                i += 1
            }
            var temp = String()
            let index = st.index(st.startIndex, offsetBy: 0)
            temp.append(st[index])
            
            let idx = self.indexList_backup.index(of: temp)!
            
            var u:[[String:AnyObject]] = []
            for dict in self.arrindex_backup[idx] {
                let fn = (dict["state_name"] as! String?)!
                if fn.lowercased().hasPrefix(st.lowercased()) {
                    u.append(dict)
                }
            }
            t[idx] = u

            arrindex = [u]
            indexList = [temp]
        }
        self.tblView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
        self.tabBar.selectedItem?.tag = 0
        //SwiftSpinner.hide()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return indexList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrindex[section].count;
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return indexList[section]
    }
    
    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return indexList
    }
    
    func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        var tpIndex:Int = 0
        
        for character in indexList{
            //判断索引值和组名称相等，返回组坐标
            if character == title{
                return tpIndex
            }
            tpIndex += 1
        }
        return 0
    }
    
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if item.tag == 0 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
            
        }
        else if item.tag == 1 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
                        self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
        else{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
                        self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
    }
    
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "legislators", for: indexPath)
        //cell.label.text = data[indexPath.row]
        var dict = arrindex[indexPath.section][indexPath.row]
        var ln = dict["last_name"] as! String?
        let fn = dict["first_name"] as! String?
        let id = dict["bioguide_id"] as! String?
        ln = ln! + " " + fn!
        cell.textLabel?.text = ln
        cell.detailTextLabel?.text = dict["state_name"] as? String
        var pic_url = "https://theunitedstates.io/images/congress/original/"
        pic_url = pic_url + id! + ".jpg"
        let url = URL(string: pic_url)
        let data = try? Data(contentsOf: url!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
        cell.imageView?.image = UIImage(data: data!)
        /*cell.textLabel?.text = data[indexPath.row]
         cell.detailTextLabel?.text = sub_data[indexPath.row]
         cell.imageView?.image = UIImage(named: "emptyStar")*/
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "leg"){
            
            let newView = segue.destination as! CustomVC
            let n = self.tblView.indexPathForSelectedRow?.row
            let m = self.tblView.indexPathForSelectedRow?.section
            
            //print(n)
            var dict = arrindex[m!][n!]
            let id = dict["bioguide_id"] as! String?
            temp = id!
            var pic_url1 = "https://theunitedstates.io/images/congress/original/"
            pic_url1 = pic_url1 + id! + ".jpg"
            pic_url = pic_url1
            fn = (dict["first_name"] as! String?)!
            ln = (dict["last_name"] as! String?)!
            state = (dict["state_name"] as! String?)!
            if (dict["first_name"] as! String?)! == "M" {
                gen = "Male"
            }
            else{
                gen = "Female"
            }
            bd = (dict["birthday"] as! String?)!
            ch = (dict["chamber"] as! String?)!
            if ((dict["fax"] as? String) != nil){
                fax = (dict["fax"] as! String?)!
            }
            else{
                fax = "NA"
            }
            //fax = (dict["fax"] as! String?)!
            
            if ((dict["twitter_id"] as? String) != nil){
                twi = "https://twitter.com/" + (dict["twitter_id"] as! String?)!
            }
            else{
                twi = "NA"
            }
            
            if ((dict["facebook_id"] as? String) != nil){
                fb = "https://www.facebook.com/" + (dict["facebook_id"] as! String?)!
            }
            else{
                fb = "NA"
            }
            
            if ((dict["website"] as? String) != nil){
                web = (dict["website"] as! String?)!
            }
            else{
                web = "NA"
            }
            
            if ((dict["office"] as? String) != nil){
                off = (dict["office"] as! String?)!
            }
            else{
                off = "NA"
            }
            et = (dict["term_end"] as! String?)!
            newView.text = temp
            newView.pic_url = pic_url
            newView.fn = fn
            newView.ln = ln
            newView.state = state
            newView.gen = gen
            newView.bd = bd
            newView.ch = ch
            newView.fax = fax
            newView.twi = twi
            newView.fb = fb
            newView.web = web
            newView.off = off
            newView.et = et
        }
        
    }
    
}


extension MainViewController: SlideMenuControllerDelegate {
    
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
    
    
}
