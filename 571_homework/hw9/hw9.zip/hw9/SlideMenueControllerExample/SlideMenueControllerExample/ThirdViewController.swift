//
//  ViewController.swift
//  hw
//
//  Created by quitz on 2016/11/26.
//  Copyright © 2016年 LDC. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner
class ThirdViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITabBarDelegate, UISearchBarDelegate{
    
    let data = ["title1","title2","title3","title4","title5"]
    let sub_data = ["stitle1","stitle2","stitle3","stitle4","stitle5"]
    var temp = ""
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = ""
    var ch = ""
    var fax = ""
    var twi = ""
    var fb = ""
    var web = ""
    var off = ""
    var et = ""
    var arrRes = [[String:AnyObject]]() //Array of dictionary
    var arrRes_back = [[String:AnyObject]]() //Array of dictionary
    var arrindex:[String:[String]] = [:]
    let indexList = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var tabBar: UITabBar!
    @IBOutlet weak var sBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        tabBar.delegate = self
        sBar.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
        Alamofire.request("http://quitz-env.us-west-2.elasticbeanstalk.com/?dbName=legislators&chamber=senate").responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["results"].arrayObject {
                    self.arrRes = resData as! [[String:AnyObject]]
                    self.arrRes.sort{($0["last_name"] as! String?)! < ($1["last_name"] as! String?)! }
                    //print(self.arrRes.count)
                    self.arrRes_back = self.arrRes
                    self.tblView.reloadData()
                }
            }
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
        //SwiftSpinner.hide()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRes.count;
        //return 20
    }
    
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if item.tag == 0 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
            
        }
        else if item.tag == 1 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
        else{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //self.arrRes = self.arrRes_back
        if searchText == "" {
            self.arrRes = self.arrRes_back
        }
        else { // 匹配用户输入内容的前缀(不区分大小写)
            var t = [[String:AnyObject]]()
            for dict in self.arrRes_back {
                let fn = (dict["first_name"] as! String?)!
                if fn.lowercased().hasPrefix(searchText.lowercased()) {
                    t.append(dict)
                }
            }
            self.arrRes = t
        }
        // 刷新Table View显示
        self.tblView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.arrRes = self.arrRes_back
        searchBar.text = ""
        searchBar.resignFirstResponder()
        self.tblView.reloadData()
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "legBySenate", for: indexPath)
        //cell.label.text = data[indexPath.row]
        var dict = arrRes[indexPath.row]
        var ln = dict["last_name"] as! String?
        let fn = dict["first_name"] as! String?
        let id = dict["bioguide_id"] as! String?
        ln = ln! + " " + fn!
        cell.textLabel?.text = ln
        cell.detailTextLabel?.text = dict["state_name"] as? String
        var pic_url = "https://theunitedstates.io/images/congress/original/"
        pic_url = pic_url + id! + ".jpg"
        let url = URL(string: pic_url)
        let data = try? Data(contentsOf: url!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
        cell.imageView?.image = UIImage(data: data!)
        /*cell.textLabel?.text = data[indexPath.row]
         cell.detailTextLabel?.text = sub_data[indexPath.row]
         cell.imageView?.image = UIImage(named: "emptyStar")*/
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "leg_senate"){
            
            let newView = segue.destination as! CustomVC
            let n = self.tblView.indexPathForSelectedRow?.row
            //print(n)
            var dict = arrRes[n!]
            let id = dict["bioguide_id"] as! String?
            temp = id!
            var pic_url1 = "https://theunitedstates.io/images/congress/original/"
            pic_url1 = pic_url1 + id! + ".jpg"
            pic_url = pic_url1
            fn = (dict["first_name"] as! String?)!
            ln = (dict["last_name"] as! String?)!
            state = (dict["state_name"] as! String?)!
            if (dict["first_name"] as! String?)! == "M" {
                gen = "Male"
            }
            else{
                gen = "Female"
            }
            bd = (dict["birthday"] as! String?)!
            ch = (dict["chamber"] as! String?)!
            if ((dict["fax"] as? String) != nil){
                fax = (dict["fax"] as! String?)!
            }
            else{
                fax = "NA"
            }
            //fax = (dict["fax"] as! String?)!
            
            if ((dict["twitter_id"] as? String) != nil){
                twi = "https://twitter.com/" + (dict["twitter_id"] as! String?)!
            }
            else{
                twi = "NA"
            }
            
            if ((dict["facebook_id"] as? String) != nil){
                fb = "https://www.facebook.com/" + (dict["facebook_id"] as! String?)!
            }
            else{
                fb = "NA"
            }
            
            if ((dict["website"] as? String) != nil){
                web = (dict["website"] as! String?)!
            }
            else{
                web = "NA"
            }
            
            if ((dict["office"] as? String) != nil){
                off = (dict["office"] as! String?)!
            }
            else{
                off = "NA"
            }
            et = (dict["term_end"] as! String?)!
            newView.text = temp
            newView.pic_url = pic_url
            newView.fn = fn
            newView.ln = ln
            newView.state = state
            newView.gen = gen
            newView.bd = bd
            newView.ch = ch
            newView.fax = fax
            newView.twi = twi
            newView.fb = fb
            newView.web = web
            newView.off = off
            newView.et = et
        }
        
    }
    
    
}

