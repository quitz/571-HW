//
//  CustomComVC.swift
//  SlideMenueControllerExample
//
//  Created by quitz on 2016/11/28.
//  Copyright © 2016年 Jeff Schmitz. All rights reserved.
//

import UIKit
import SwiftSpinner
class CustomComVC: UIViewController, UITableViewDataSource, UITableViewDelegate,UITextViewDelegate {
    
    @IBOutlet weak var comContent: UITextView!
    @IBOutlet weak var comTable: UITableView!
    @IBOutlet weak var likeButton: UIButton!
    
    var llabel = ["ID","Parent ID","Chamber","Office","Contact"]
    
    var text = ""
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = ""
    var ch = ""
    var fax = ""
    var twi = ""
    var fb = ""
    var web = ""
    var off = ""
    var et = ""
    var rlabel = [String]()
    
    
    @IBAction func likeCom(_ sender: Any) {
        let t = fn + ln
        if fav_com_list.contains(t) {
            //likeButton.imageView?.image = UIImage(named: "Star")
            likeButton.setImage(UIImage(named: "Star"), for: [])
            
            let idx = fav_com_list.index(of: t)!
            fav_com_list.remove(at: idx)
            fav_com.remove(at: idx)
        }
        else {
            likeButton.setImage(UIImage(named: "fillStar"), for: [])
            fav_com.append(rlabel)
            fav_com_list.append(t)
        }
        
        print(fav_com)
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        //SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        rlabel.append(fn)
        rlabel.append(ln)
        rlabel.append(state)
        rlabel.append(gen)
        rlabel.append(bd)
        rlabel.append(text)
        //print(rlabel)
        //print(pic_url)
        comContent.isEditable = false
        comContent.text = text
        // Do any additional setup after loading the view.
        var t = fn + ln
        
        if fav_com_list.contains(t) {
            likeButton.imageView?.image = UIImage(named: "fillStar")
        }
        else {
            likeButton.imageView?.image = UIImage(named: "Star")
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5;
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "comdetail", for: indexPath) as! CustomComCell
        cell.leftLabel.text = llabel[indexPath.row]
        //cell.rightLabel.text = rlabel[indexPath.row]
        cell.rightLabel.text = rlabel[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        return true;
    }
    
}
