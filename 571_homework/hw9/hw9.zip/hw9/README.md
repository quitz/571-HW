Author: Ning Cui
USC ID: 7629269592
Library: 
    SlideMenuControllerSwift
    Alamofire
    SwiftyJSON
    SwiftSpinner
Icons:
    icons8.com
