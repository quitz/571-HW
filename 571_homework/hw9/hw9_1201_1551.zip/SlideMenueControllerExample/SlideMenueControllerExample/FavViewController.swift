//
//  ViewController.swift
//  hw
//
//  Created by quitz on 2016/11/26.
//  Copyright © 2016年 LDC. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner
class FavViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITabBarDelegate,UISearchBarDelegate  {
    
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = ""
    var ch = ""
    var fax = ""
    var twi = ""
    var fb = ""
    var web = ""
    var off = ""
    var et = ""
    var b = fav_leg
    var bl = fav_leg_list
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var tabBar: UITabBar!
    @IBOutlet weak var sBar: UISearchBar!
    
    
    @IBAction func filterTapped(_ sender: Any) {
        if sBar.isHidden == true {
            sBar.isHidden = false
        }
        else {
            sBar.isHidden = true
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.delegate = self
        sBar.delegate = self
        sBar.isHidden = true
        b = fav_leg
        bl = fav_leg_list
        self.tblView.reloadData()
        SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
        b = fav_leg
        bl = fav_leg_list
        self.tblView.reloadData()
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        self.tblView.reloadData()
    }
    
    
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if item.tag == 0 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "FavViewController") as! FavViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
            
        }
        else if item.tag == 1 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Fav2ViewController") as! Fav2ViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
            print("line64")
        }
        else{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Fav3ViewController") as!Fav3ViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //self.arrRes = self.arrRes_back
        if searchText == "" {
            bl = fav_leg_list
            b = fav_leg
        }
        else { // 匹配用户输入内容的前缀(不区分大小写)
            var t = [[String]]()
            var fl = [String]()
            for dict in fav_leg {
                let fn = dict[0]
                let ln = dict[1]
                if fn.lowercased().hasPrefix(searchText.lowercased()) {
                    t.append(dict)
                    fl.append(fn + ln)
                }
            }
            b = t
            bl = fl
            
        }
        // 刷新Table View显示
        self.tblView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        bl = fav_leg_list
        b = fav_leg
        searchBar.text = ""
        searchBar.resignFirstResponder()
        self.tblView.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bl.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "fav_leg", for: indexPath)
        //cell.label.text = data[indexPath.row]
        var dict = b[indexPath.row]
        var fn = dict[0]
        var ln = dict[1]
        
        ln = ln + " " + fn
        cell.textLabel?.text = ln
        cell.detailTextLabel?.text = dict[2]
        
        let t = dict[12]
        let url = URL(string: t)
        let data = try? Data(contentsOf: url!)
        cell.imageView?.image = UIImage(data: data!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "fav_leg_detail"){
            
            var dest = segue.destination as! UINavigationController
            let newView = dest.topViewController as! CustomVC
            let n = self.tblView.indexPathForSelectedRow?.row
            //print(n)
            let a = b[n!]
            newView.pic_url = a[12]
            newView.fn = a[0]
            newView.ln = a[1]
            newView.state = a[2]
            newView.gen = a[3]
            newView.bd = a[4]
            newView.ch = a[5]
            newView.fax = a[6]
            newView.twi = a[7]
            newView.fb = a[8]
            newView.web = a[9]
            newView.off = a[10]
            newView.et = a[11]
            //self.tblView.reloadData()
        }
    }
    
}

