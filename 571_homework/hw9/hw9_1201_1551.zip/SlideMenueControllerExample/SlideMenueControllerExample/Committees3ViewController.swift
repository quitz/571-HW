//
//  MainViewController.swift
//  SlideMenueControllerExample
//
//  Created by Jeff Schmitz on 10/14/16.
//  Copyright © 2016 Jeff Schmitz. All rights reserved.
//

import UIKit
import SlideMenuControllerSwift
import Alamofire
import SwiftyJSON
import SwiftSpinner
class Committees3ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITabBarDelegate,UISearchBarDelegate  {
    @IBOutlet weak var sBar: UISearchBar!
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var tabBar: UITabBar!
    
    let data = ["title1","title2","title3","title4","title5"]
    let sub_data = ["stitle1","stitle2","stitle3","stitle4","stitle5"]
    var temp = ""
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = ""
    var ch = ""
    var fax = ""
    var twi = ""
    var fb = ""
    var web = ""
    var off = ""
    var et = ""
    var arrRes = [[String:AnyObject]]() //Array of dictionary
    var arrRes_back = [[String:AnyObject]]() //
    var arrindex:[String:[String]] = [:]
    let indexList = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        tabBar.delegate = self
        sBar.delegate = self
        sBar.isHidden = true
        // Do any additional setup after loading the view, typically from a nib.
        
        Alamofire.request("http://104.198.0.197:8080/committees?per_page=all&chamber=joint").responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["results"].arrayObject {
                    self.arrRes = resData as! [[String:AnyObject]]
                    self.arrRes.sort{($0["name"] as! String?)! < ($1["name"] as! String?)! }
                    self.arrRes_back = self.arrRes
                    self.tblView.reloadData()
                }
            }
            
        }
        
        //print(arrRes.count)
    }
    @IBAction func filterTapped(_ sender: Any) {
        if sBar.isHidden == true {
            sBar.isHidden = false
        }
        else {
            sBar.isHidden = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRes.count;
        //return 20
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //self.arrRes = self.arrRes_back
        if searchText == "" {
            self.arrRes = self.arrRes_back
        }
        else { // 匹配用户输入内容的前缀(不区分大小写)
            var t = [[String:AnyObject]]()
            for dict in self.arrRes_back {
                let fn = (dict["name"] as! String?)!
                
                if fn.lowercased().contains(searchText.lowercased()) {
                    t.append(dict)
                }
            }
            self.arrRes = t
        }
        // 刷新Table View显示
        self.tblView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.arrRes = self.arrRes_back
        searchBar.text = ""
        searchBar.resignFirstResponder()
        self.tblView.reloadData()
        
    }
    
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if item.tag == 0 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "CommitteesViewController") as! CommitteesViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
            
        }
        else if item.tag == 1 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Committees2ViewController") as! Committees2ViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
        else{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Committees3ViewController") as! Committees3ViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
    }
    /*func sectionIndexTitles(for tableView: UITableView) -> [String]? {
     <#code#>
     }
     func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
     <#code#>
     }
     func numberOfSections(in tableView: UITableView) -> Int {
     return indexList.count
     }
     
     func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
     return indexList[section]
     }*/
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "committees3", for: indexPath)
        //cell.label.text = data[indexPath.row]
        var dict = arrRes[indexPath.row]
        let ln = dict["name"] as! String?
        let fn = dict["committee_id"] as! String?
        
        cell.textLabel?.text = ln!
        cell.detailTextLabel?.text = fn!
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "com3"){
            var dest = segue.destination as! UINavigationController
            let newView = dest.topViewController as! CustomComVC
            
            let n = self.tblView.indexPathForSelectedRow?.row
            //print(n)
            var dict = arrRes[n!]
            
            fn = (dict["committee_id"] as! String?)!
            if ((dict["parent_committee_id"] as? String) != nil){
                ln = (dict["parent_committee_id"] as! String?)!
            }
            else{
                ln = "NA"
            }
            
            state = (dict["chamber"] as! String?)!
            if ((dict["office"] as? String) != nil){
                gen = (dict["office"] as! String?)!
            }
            else{
                gen = "NA"
            }
            
            if ((dict["phone"] as? String) != nil){
                bd = (dict["phone"] as! String?)!
            }
            else{
                bd = "NA"
            }
            
            temp = (dict["name"] as! String?)!
            
            newView.text = temp
            
            newView.fn = fn
            newView.ln = ln
            newView.state = state
            newView.gen = gen
            newView.bd = bd
            newView.ch = ch
            newView.fax = fax
            newView.twi = twi
            newView.fb = fb
            newView.web = web
            newView.off = off
            newView.et = et
        }
        
    }
    
}

