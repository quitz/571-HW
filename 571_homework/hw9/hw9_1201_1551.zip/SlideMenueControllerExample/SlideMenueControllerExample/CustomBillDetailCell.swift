//
//  CustomBillDetailCell.swift
//  SlideMenueControllerExample
//
//  Created by quitz on 2016/11/28.
//  Copyright © 2016年 Jeff Schmitz. All rights reserved.
//

import UIKit

class CustomBillDetailCell: UITableViewCell {

    @IBOutlet weak var leftLabel: UILabel!
    @IBOutlet weak var right: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
