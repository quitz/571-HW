//
//  ViewController.swift
//  hw
//
//  Created by quitz on 2016/11/26.
//  Copyright © 2016年 LDC. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner
class Swift2ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate,UITabBarDelegate,  UISearchBarDelegate  {
    
    var temp = ""
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = NSMutableAttributedString(string: " " )
    var ch = ""
    var fax = ""
    var twi = ""
    var arrRes = [[String:AnyObject]]() //Array of dictionary
    var arrRes_back = [[String:AnyObject]]()
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var tabBar: UITabBar!
    
    @IBOutlet weak var sBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        tabBar.delegate = self
        sBar.delegate = self
        sBar.isHidden = true
        // Do any additional setup after loading the view, typically from a nib.
        Alamofire.request("http://quitz-env.us-west-2.elasticbeanstalk.com/?dbName=bills&act=false").responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["results"].arrayObject {
                    self.arrRes = resData as! [[String:AnyObject]]
                    self.arrRes.sort{($0["introduced_on"] as! String?)! > ($1["introduced_on"] as! String?)! }
                    //print(self.arrRes[0])
                    self.arrRes_back = self.arrRes
                    self.tblView.reloadData()
                }
            }
            
        }
    }
    
    @IBAction func filterTapped(_ sender: Any) {
        if sBar.isHidden == true {
            sBar.isHidden = false
        }
        else {
            sBar.isHidden = true
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
    }
    
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if item.tag == 0 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "SwiftViewController") as! SwiftViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
            
        }
        else if item.tag == 1 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Swift2ViewController") as! Swift2ViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //self.arrRes = self.arrRes_back
        if searchText == "" {
            self.arrRes = self.arrRes_back
        }
        else { // 匹配用户输入内容的前缀(不区分大小写)
            var t = [[String:AnyObject]]()
            for dict in self.arrRes_back {
                let fn = (dict["official_title"] as! String?)!
                
                if fn.lowercased().contains(searchText.lowercased()) {
                    t.append(dict)
                }
            }
            self.arrRes = t
        }
        // 刷新Table View显示
        self.tblView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.arrRes = self.arrRes_back
        searchBar.text = ""
        searchBar.resignFirstResponder()
        self.tblView.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRes.count;
        //return 20
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "bill_2", for: indexPath) as! CustomBillCell
        //cell.label.text = data[indexPath.row]
        var dict = arrRes[indexPath.row]
        let ln = dict["bill_id"] as! String?
        let fn = dict["official_title"] as! String?
        cell.billId.text = ln!
        cell.billContent.text = fn!
        cell.billContent.isEditable = false
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "bill_new"){
            
            var dest = segue.destination as! UINavigationController
            let newView = dest.topViewController as! CustomBillVC
            let n = self.tblView.indexPathForSelectedRow?.row
            //print(n)
            var dict = arrRes[n!]
            let swiftyJsonVar = JSON(dict)
            let sfn = swiftyJsonVar["sponsor"]["first_name"]
            let sln = swiftyJsonVar["sponsor"]["last_name"]
            let sti = swiftyJsonVar["sponsor"]["title"]
            let pdf = swiftyJsonVar["last_version"]["urls"]["pdf"]
            if sfn == nil || sln == nil || sti == nil {
                state = "NA"
            }
            else{
                state = sti.string! + " " + sln.string! + " " + sfn.string!
            }
            
            
            if pdf == nil {
                bd = NSMutableAttributedString(string: "NA" )
            }
            else {
                bd = NSMutableAttributedString(string: pdf.string! )
            }
            
            //var a = "fsadsafwrefdsafdatertdfgrwersadfsdfcvxcvrweqrsdacxzcfsdfsdfdsfsdfarewqwesfxcxfdfsd"
            fn = (dict["bill_id"] as! String?)!
            ln = (dict["bill_type"] as! String?)!
            gen = (dict["last_action_at"] as! String?)!
            ch = (dict["chamber"] as! String?)!
            print("line139")
            print(bd.string)
            if ((dict["last_vote_at"] as? String) != nil){ //tobe done
                fax = (dict["last_vote_at"] as! String?)!
            }
            else{
                fax = "NA"
            }
            
            twi = "New"
            let ot = dict["official_title"] as! String?
            newView.fn = fn
            newView.ln = ln
            newView.state = state
            newView.gen = gen
            newView.bd = bd
            newView.ch = ch
            newView.fax = fax
            newView.twi = twi
            newView.ot = ot!
        }
    }
}

