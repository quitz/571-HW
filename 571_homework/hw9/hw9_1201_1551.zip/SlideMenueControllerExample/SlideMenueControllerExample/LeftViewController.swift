//
//  LeftViewController.swift
//  SlideMenueControllerExample
//
//  Created by Jeff Schmitz on 10/14/16.
//  Copyright © 2016 Jeff Schmitz. All rights reserved.
//

import UIKit

enum LeftMenu: Int {
    case main = 0       //legislators
    case swift          //bills//xx
    case committees     // committees
    case fav            //favorites
    case aboutMe        //about me
    case house
    case senate
    case new
    //case tb
}

protocol LeftMenuProtocol: class {
    func changeViewController(_ menu: LeftMenu)
}

class LeftViewController: UIViewController, LeftMenuProtocol
{
    @IBOutlet weak var tableView: UITableView!
 
    var menus = ["Legislators", "Bills","Committees","Favorites","AboutMe"]
    var mainViewController: UIViewController!
    var swiftViewController: UIViewController!
    var swift2ViewController: UIViewController!
    //var nonMenuViewController: UIViewController!
    var aboutMeViewController: UIViewController!
    var committeesViewController: UIViewController!
    var favViewController: UIViewController!
    var secondViewController: UIViewController!
    var thirdViewController: UIViewController!
    //var TBController: UITabBarController!
    //var imageHeaderView: ImageHeaderView!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.separatorColor = UIColor(red: 224/255, green: 224/255, blue: 224/255, alpha: 1.0)
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        let mainViewController = storyboard.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
        self.mainViewController = UINavigationController(rootViewController: mainViewController)
        
        let swiftViewController = storyboard.instantiateViewController(withIdentifier: "SwiftViewController") as! SwiftViewController
        self.swiftViewController = UINavigationController(rootViewController: swiftViewController)
        
        let swift2ViewController = storyboard.instantiateViewController(withIdentifier: "Swift2ViewController") as! Swift2ViewController
        self.swift2ViewController = UINavigationController(rootViewController: swift2ViewController)
        
        self.aboutMeViewController = storyboard.instantiateViewController(withIdentifier: "AboutMeViewController") as! AboutMeViewController
        self.aboutMeViewController = UINavigationController(rootViewController: aboutMeViewController)
        
        self.committeesViewController = storyboard.instantiateViewController(withIdentifier: "CommitteesViewController") as! CommitteesViewController
        self.committeesViewController = UINavigationController(rootViewController: committeesViewController)
        
        self.favViewController = storyboard.instantiateViewController(withIdentifier: "FavViewController") as! FavViewController
        self.favViewController = UINavigationController(rootViewController: favViewController)
        
        self.secondViewController = storyboard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.secondViewController = UINavigationController(rootViewController: secondViewController)
        
        self.thirdViewController = storyboard.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        self.thirdViewController = UINavigationController(rootViewController: thirdViewController)
        
//        self.tableView.registerCellClass(BaseTableViewCell.self)
        
        //self.imageHeaderView = ImageHeaderView.loadNib()
        //self.view.addSubview(self.imageHeaderView)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        //self.imageHeaderView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 160)
        self.view.layoutIfNeeded()
    }
    
    func changeViewController(_ menu: LeftMenu) {
        switch menu {
        case .main:
            self.mainViewController.tabBarItem.tag = 0
            self.slideMenuController()?.changeMainViewController(self.mainViewController, close: true)
            
        case .swift:
            self.swiftViewController.tabBarItem.tag = 0
            self.slideMenuController()?.changeMainViewController(self.swiftViewController, close: true)
        case .new:
            self.slideMenuController()?.changeMainViewController(self.swift2ViewController, close: true)
        case .aboutMe:
            self.slideMenuController()?.changeMainViewController(self.aboutMeViewController, close: true)
        case .committees:
            self.committeesViewController.tabBarItem.tag = 0
            self.slideMenuController()?.changeMainViewController(self.committeesViewController, close: true)
        case .fav:
            self.favViewController.tabBarItem.tag = 0
            self.slideMenuController()?.changeMainViewController(self.favViewController, close: true)
        case .house:
            self.slideMenuController()?.changeMainViewController(self.secondViewController, close: true)
        case .senate:
            self.slideMenuController()?.changeMainViewController(self.thirdViewController, close: true)
        }
    }
}

extension LeftViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if let menu = LeftMenu(rawValue: indexPath.row) {
            switch menu {
            case .main, .swift,.aboutMe, .committees, .fav, .house, .senate, .new:
                return BaseTableViewCell.height()
            }
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let menu = LeftMenu(rawValue: indexPath.row) {
            self.changeViewController(menu)
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if self.tableView == scrollView {
            
        }
    }
}

extension LeftViewController : UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menus.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let menu = LeftMenu(rawValue: indexPath.row) {
            switch menu {
            case .main, .swift, .aboutMe, .committees, .fav, .house, .senate, .new:
                let cell = BaseTableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: BaseTableViewCell.identifier)
                cell.setData(menus[indexPath.row])
                return cell
            }
        }
        return UITableViewCell()
    }
}


