//
//  CustomBillCell.swift
//  SlideMenueControllerExample
//
//  Created by quitz on 2016/11/27.
//  Copyright © 2016年 Jeff Schmitz. All rights reserved.
//

import UIKit

class CustomBillCell: UITableViewCell {

    @IBOutlet weak var billId: UILabel!
    
    @IBOutlet weak var billContent: UITextView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
