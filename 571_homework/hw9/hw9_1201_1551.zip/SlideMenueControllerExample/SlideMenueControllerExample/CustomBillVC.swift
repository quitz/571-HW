//
//  CustomVC.swift
//  SlideMenueControllerExample
//
//  Created by quitz on 2016/11/27.
//  Copyright © 2016年 Jeff Schmitz. All rights reserved.
//

import UIKit
import SwiftSpinner

class CustomBillVC: UIViewController, UITableViewDataSource, UITableViewDelegate,UITextViewDelegate {
    
    @IBOutlet weak var billContent: UITextView!
    @IBOutlet weak var billTable: UITableView!
    
    
    @IBOutlet weak var navigation: UINavigationItem!
    
    var llabel = ["Bill ID","Bill Type","Sponsor","Last Action","PDF","Chamber","Last Vote","Status"]
    
    let dict = ["01":"Jan","02":"Feb","03":"Mar","04":"Apr","05":"May","06":"Jun","07":"Jul","08":"Aug","09":"Sep","10":"Oct","11":"Nov","12":"Dec"]
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = NSMutableAttributedString(string: " " )
    var ch = ""
    var fax = ""
    var twi = ""
    var ot = ""
    var use1 = ""
    var use2 = ""
    var rlabel = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        rlabel.append(fn)
        rlabel.append(ln.uppercased())
        rlabel.append(state)
        var bd = gen
        rlabel.append(gen)
        if gen == "NA" {
            use1 = gen
        }
        else {
            let index = bd.index(bd.startIndex, offsetBy: 4)
            let t1 = bd.substring(to: index)
            let idx1 = bd.index(bd.startIndex, offsetBy: 5)
            let idx2 = bd.index(bd.startIndex, offsetBy: 7)
            let range = idx1..<idx2
            let t2 = bd.substring(with: range)
            let index1 = bd.index(bd.startIndex, offsetBy: 8)
            let index2 = bd.index(bd.startIndex, offsetBy: 10)
            let range1 = index1..<index2
            let t3 = bd.substring(with: range1)
            var tt = t3 + " " + dict[t2]! + " " + t1
            use1 = tt
        }
        //rlabel.append(gen)
        rlabel.append("NA")
        rlabel.append(ch)
        
        var bd1 = fax
        rlabel.append(fax)
        if fax == "NA" {
            use2 = fax
        }
        else {
            let iindex = bd1.index(bd1.startIndex, offsetBy: 4)
            let it1 = bd1.substring(to: iindex)
            let iidx1 = bd1.index(bd1.startIndex, offsetBy: 5)
            let iidx2 = bd1.index(bd1.startIndex, offsetBy: 7)
            let irange = iidx1..<iidx2
            let it2 = bd1.substring(with: irange)
            let iindex1 = bd1.index(bd1.startIndex, offsetBy: 8)
            let iindex2 = bd1.index(bd1.startIndex, offsetBy: 10)
            let irange1 = iindex1..<iindex2
            let it3 = bd1.substring(with: irange1)
            var itt = it3 + " " + dict[it2]! + " " + it1
            use2 = itt
        }
        //
        rlabel.append(twi)
        rlabel.append(ot)
        billContent.text = ot
        billContent.isEditable = false
        // Do any additional setup after loading the view.
        let t = fn
        var pic_name = ""
        if fav_bill_list.contains(t) {
            pic_name = "fillStar"
        }
        else {
            
            pic_name = "Star"
        }
        let button = UIButton.init(type: .custom)
        
        button.setImage(UIImage.init(named: pic_name), for: UIControlState.normal)
        button.addTarget(self, action:#selector(callMethod), for: UIControlEvents.touchUpInside)
        button.frame = CGRect.init(x: 0, y: 0, width: 30, height: 30) //CGRectMake(0, 0, 30, 30)
        let barButton = UIBarButtonItem.init(customView: button)
        self.navigationItem.rightBarButtonItem = barButton
    }
    
    func callMethod() {
        let t = fn
        var pic = ""
        if fav_bill_list.contains(t) {
            //likeButton.imageView?.image = UIImage(named: "Star")
            pic = "Star"
            
            let idx = fav_bill_list.index(of: t)!
            fav_bill_list.remove(at: idx)
            fav_bill.remove(at: idx)
        }
        else {
            pic = "fillStar"
            fav_bill.append(rlabel)
            fav_bill_list.append(t)
        }
        let button = UIButton.init(type: .custom)
        
        button.setImage(UIImage.init(named: pic), for: UIControlState.normal)
        button.addTarget(self, action:#selector(callMethod), for: UIControlEvents.touchUpInside)
        button.frame = CGRect.init(x: 0, y: 0, width: 30, height: 30) //CGRectMake(0, 0, 30, 30)
        let barButton = UIBarButtonItem.init(customView: button)
        self.navigationItem.rightBarButtonItem = barButton
        
    }
    
    @IBAction func goBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8;
        //return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "billdetail", for: indexPath) as! CustomBillDetailCell
        cell.leftLabel.text = llabel[indexPath.row]
        
        //cell.rightLabel.text = rlabel[indexPath.row]
        cell.right.text = rlabel[indexPath.row]
        cell.right.isEditable = false
        if indexPath.row == 4 && bd.string != "NA" {
            let linkAttributes = [
                NSLinkAttributeName: NSURL(string: bd.string)!,
                NSForegroundColorAttributeName: UIColor.blue
                ] as [String : Any]
            
            let attributedString = NSMutableAttributedString(string: "PDF Link")
            
            // Set the 'click here' substring to be the link
            attributedString.setAttributes(linkAttributes, range: NSMakeRange(0, 8))
            
            cell.right.delegate = self
            cell.right.attributedText = attributedString
            cell.right.isEditable = false;
        }
        else if indexPath.row == 3 {
            cell.right.text = use1
        }
        else if indexPath.row == 6{
            cell.right.text = use2
        }
        else {
            
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        return true;
    }
    
}
