//
//  ViewController.swift
//  hw
//
//  Created by quitz on 2016/11/26.
//  Copyright © 2016年 LDC. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner
class Fav2ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITabBarDelegate, UISearchBarDelegate  {
    
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = ""
    var ch = ""
    var fax = ""
    var twi = ""
    var fb = ""
    var web = ""
    var off = ""
    var et = ""
    
    var b = fav_bill
    var bl = fav_bill_list
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var tabBar: UITabBar!
    @IBOutlet weak var sBar: UISearchBar!
    
    @IBAction func filterTapped(_ sender: Any) {
        if sBar.isHidden == true {
            sBar.isHidden = false
        }
        else {
            sBar.isHidden = true
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.delegate = self
        sBar.delegate = self
        sBar.isHidden = true
        b = fav_bill
        bl = fav_bill_list
        self.tblView.reloadData()
        SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        //print(fav_bill[0][8])
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
        b = fav_bill
        bl = fav_bill_list
        self.tblView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        self.tblView.reloadData()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        self.tblView.reloadData()
    }
    
    
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if item.tag == 0 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "FavViewController") as! FavViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
            
        }
        else if item.tag == 1 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Fav2ViewController") as! Fav2ViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
        else{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Fav3ViewController") as!Fav3ViewController
            self.slideMenuController()?.changeMainViewController(UINavigationController(rootViewController: vc), close: true)
        }
    }

    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //self.arrRes = self.arrRes_back
        if searchText == "" {
            bl = fav_bill_list
            b = fav_bill
        }
        else { // 匹配用户输入内容的前缀(不区分大小写)
            var t = [[String]]()
            var fl = [String]()
            for dict in fav_bill {
                let fn = dict[0]
                let ln = dict[1]
                let tn = dict[8]
                if tn.lowercased().contains(searchText.lowercased()) {
                    t.append(dict)
                    fl.append(fn + ln)                    
                }
            }
            b = t
            bl = fl
            
        }
        // 刷新Table View显示
        self.tblView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        bl = fav_bill_list
        b = fav_bill
        searchBar.text = ""
        searchBar.resignFirstResponder()
        self.tblView.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bl.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "fav_bill", for: indexPath) as! CustomFavBillCell
        //cell.label.text = data[indexPath.row]
        var dict = b[indexPath.row]
        let t = dict[8]
        cell.hLabel.text = ""
        cell.billFavContent.isEditable = false
        cell.billFavContent.text = t
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("line94")
        if segue.identifier == "fav_bill_detail" {
            
            var dest = segue.destination as! UINavigationController
            let newView = dest.topViewController as! CustomBillVC
            let n = self.tblView.indexPathForSelectedRow?.row
            //print(n)
            let a = b[n!]
            newView.fn = a[0]
            newView.ln = a[1]
            newView.state = a[2]
            newView.gen = a[3]
            newView.bd = NSMutableAttributedString(string: "https://www.gpo.gov/fdsys/pkg/BILLS-114sconres41rfh/pdf/BILLS-114sconres41rfh.pdf" )
            newView.ch = a[5]
            newView.fax = a[6]
            newView.twi = a[7]
            newView.ot = a[8]
            //self.tblView.reloadData()
        }
    }
}

