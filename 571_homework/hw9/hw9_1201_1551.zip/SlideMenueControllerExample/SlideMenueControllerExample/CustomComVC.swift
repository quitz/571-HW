//
//  CustomComVC.swift
//  SlideMenueControllerExample
//
//  Created by quitz on 2016/11/28.
//  Copyright © 2016年 Jeff Schmitz. All rights reserved.
//

import UIKit
import SwiftSpinner
class CustomComVC: UIViewController, UITableViewDataSource, UITableViewDelegate,UITextViewDelegate {
    
    @IBOutlet weak var comContent: UITextView!
    @IBOutlet weak var comTable: UITableView!
    @IBOutlet weak var navigation: UINavigationItem!
    
    var llabel = ["ID","Parent ID","Chamber","Office","Contact"]
    
    var text = ""
    var pic_url = ""
    var fn = ""
    var ln = ""
    var state = ""
    var gen = ""
    var bd = ""
    var ch = ""
    var fax = ""
    var twi = ""
    var fb = ""
    var web = ""
    var off = ""
    var et = ""
    var rlabel = [String]()
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        //SwiftSpinner.show(duration: 1.0, title: "Fetching Data....")
        rlabel.append(fn)
        rlabel.append(ln)
        rlabel.append(state)
        rlabel.append(gen)
        rlabel.append(bd)
        rlabel.append(text)
        //print(rlabel)
        //print(pic_url)
        comContent.isEditable = false
        comContent.text = text
        // Do any additional setup after loading the view.
        var t = fn + ln
        
        var pic_name = ""
        if fav_com_list.contains(t) {
            pic_name = "fillStar"
        }
        else {
            pic_name = "Star"
        }
        let button = UIButton.init(type: .custom)
        
        button.setImage(UIImage.init(named: pic_name), for: UIControlState.normal)
        button.addTarget(self, action:#selector(callMethod), for: UIControlEvents.touchUpInside)
        button.frame = CGRect.init(x: 0, y: 0, width: 30, height: 30) //CGRectMake(0, 0, 30, 30)
        let barButton = UIBarButtonItem.init(customView: button)
        self.navigationItem.rightBarButtonItem = barButton
    }
    
    func callMethod() {
        let t = fn + ln
        var pic = ""
        if fav_com_list.contains(t) {
            //likeButton.imageView?.image = UIImage(named: "Star")
            pic = "Star"
            
            let idx = fav_com_list.index(of: t)!
            fav_com_list.remove(at: idx)
            fav_com.remove(at: idx)
        }
        else {
            pic = "fillStar"
            fav_com.append(rlabel)
            fav_com_list.append(t)
        }
        let button = UIButton.init(type: .custom)
        
        button.setImage(UIImage.init(named: pic), for: UIControlState.normal)
        button.addTarget(self, action:#selector(callMethod), for: UIControlEvents.touchUpInside)
        button.frame = CGRect.init(x: 0, y: 0, width: 30, height: 30) //CGRectMake(0, 0, 30, 30)
        let barButton = UIBarButtonItem.init(customView: button)
        self.navigationItem.rightBarButtonItem = barButton
        
    }
    
    @IBAction func goBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5;
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "comdetail", for: indexPath) as! CustomComCell
        cell.leftLabel.text = llabel[indexPath.row]
        //cell.rightLabel.text = rlabel[indexPath.row]
        cell.rightLabel.text = rlabel[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        return true;
    }
    
}
